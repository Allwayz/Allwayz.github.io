package com.opslab.functions;

/**
 * 属性过滤接口
 */
public interface PropertyFilter {
    public String Properties(String pro);
}
